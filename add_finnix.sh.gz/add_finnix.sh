#!/bin/bash

# Define variables
ISO_URL="http://45.64.132.123:5103/finnix.iso"  # URL to download the Finnix ISO
ISO_PATH="/boot/finnix.iso"
GRUB_CUSTOM_FILE="/etc/grub.d/40_custom"
GRUB_DEFAULT_FILE="/etc/default/grub"
FINNIX_MENU_ENTRY="Finnix Live Boot"  # Define the GRUB menu entry name

# Step 1: Download the Finnix ISO
echo "Downloading Finnix ISO..."
wget -O $ISO_PATH $ISO_URL

# Step 2: Add the GRUB entry for Finnix
echo "Adding GRUB entry for Finnix..."
cat <<EOF >> $GRUB_CUSTOM_FILE

menuentry "$FINNIX_MENU_ENTRY" {
    set iso_path="$ISO_PATH"
    loopback loop \$iso_path
    linux (loop)/live/vmlinuz-6.8.12-amd64 boot=live toram findiso=\$iso_path
    initrd (loop)/live/initrd.img-6.8.12-amd64
}
EOF

# Step 3: Update GRUB to recognize the new entry
echo "Updating GRUB to recognize new entries..."
update-grub

# Step 4: Set Finnix as the default boot option
echo "Setting Finnix as the default boot option..."
sed -i "s/^GRUB_DEFAULT=.*/GRUB_DEFAULT=\"$FINNIX_MENU_ENTRY\"/" $GRUB_DEFAULT_FILE

# Step 5: Update GRUB again to apply the changes
echo "Updating GRUB to apply default boot option..."
update-grub

echo "Finnix has been added as a boot option and set as the default boot entry."
